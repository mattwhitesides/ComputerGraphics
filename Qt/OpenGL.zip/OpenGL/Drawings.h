#ifndef DRAWINGS_H
#define DRAWINGS_H


class Drawings
{
public:

    static void drawLine(int x1, int y1, int x2, int y2);

};

#endif // DRAWINGS_H
