/*
 *	MyWindow.cpp
 *
 *	Created on : Jan 26, 2013
 *  Updated on : Feb 01, 2013
 *  Course     : CS4610/7610
 *  Instructor : Kannappan Palaniappan
 *	Author	   : Rui Wang
 *	Purpose    : Main drawing&viewing Window.
 *
 *	Copyright University of Missouri-Columbia
 */


#include <stdlib.h>
#include <iostream>
#include <stdio.h>
#include <math.h>
#include <FL/Fl.H>
#include <FL/Fl_Window.H>
#include <FL/Fl_Button.H>
#include <FL/gl.h>
#include "MyWindow.h"
#include "DrawingAlgorithm.h"


const int MyWindow::CLEAR = 0;
const int MyWindow::LINE = 1;
const int MyWindow::CIRCLE = 2;
const int MyWindow::ELLIPSE = 3;
const int MyWindow::POLYGON = 4;
const int MyWindow::POLYLINE = 5;
const int MyWindow::RASTERIZE = 6;
const int MyWindow::FILLCIRCLE = 7;
const int MyWindow::SEMICIRCLE = 8;
const int MyWindow::RUBBERLINE = 9;
const int MyWindow::RUBBERCIRCLE = 10;
const int MyWindow::RUBBERPOLYLINE = 11;
const int MyWindow::DIALOGPOINT = 12;

//---------------------------MyWindow::MyWindow--------------------------------
MyWindow::MyWindow(int x,int y,int width, int height, char* title) : Fl_Gl_Window(x,y,width, height, title)
{
   mode(FL_RGB | FL_ALPHA | FL_DEPTH );

	swidth = width;
	sheight = height;
	shapeMode = 0;
	firsttime=0;
}


MyWindow::~MyWindow()
{}

//------------------------Mouse Callback Function------------------------------

void MyWindow::drawline()
{
	shapeMode = MyWindow::LINE;
}

void MyWindow::drawcircle()
{
	shapeMode = MyWindow::CIRCLE;
}

void MyWindow::drawpolyline()
{
	shapeMode = MyWindow::POLYLINE;
}

void MyWindow::drawdialogpoint()
{
	shapeMode = MyWindow::DIALOGPOINT;
    redraw();
}

//-----------------------------------------------------------------------------

// ************************************************************************
//  This function initializes the GL prior to drawing anything 
// ************************************************************************
void MyWindow::InitializeGL()
{
	
    glClearColor(0.0f, 0.0f, 0.0f, 0.0);
	glColor3f(1.0,1.0,1.0);
	
	glShadeModel(GL_FLAT);
	
	glLoadIdentity();
	glViewport(0, 0, swidth, sheight);
    
    /* These variables specify the coordinate set to be used in glOrtho() */
    /* width() gives the width of the window */
    /* height() gives the height of the window */
    /* See QWidget documentation for more info */
    GLdouble left, right, high, down;
    
    left = - (float) swidth / 2;
    right = (float) swidth / 2;
    down = - (float) sheight / 2;
    high = (float) sheight / 2;
    
	glOrtho(left, right, down,high , -1, 1);
    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
}

//-----------------------------------------------------------------------------

// ************************************************************************
// Draws the widget. Never call this function directly. If needed, call
// redraw() instead.
// ************************************************************************

void MyWindow::draw()
{
	if(firsttime==0) {
		InitializeGL();
		firsttime = 1;
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	}
    //Switch between different drawing mode.
	switch(shapeMode) {
		case MyWindow::LINE:
			if(clickCounter == 0) {
				DrawingAlgorithms::Bresenham(startX, startY, finishX, finishY);
			}
			else if(clickCounter == 1) {
				//Draw first point
				glBegin(GL_POINTS);
                glVertex2i(startX, startY);
				glEnd();
			}
            break;
            
        case MyWindow::DIALOGPOINT:
            glPointSize(5.0);
            glBegin(GL_POINTS);
            glVertex2i(dialogX, dialogY);
            glEnd();
            glPointSize(1.0);
			
		case MyWindow::CIRCLE:
			//Your own code.
            break;
            
		case MyWindow::POLYLINE:
			//Your own code.
            break;
	}
}

//-----------------------------------------------------------------------------

// ************************************************************************
// Handle events(eg. mouse, keyboard) in your program or widget
// ************************************************************************

int MyWindow::handle(int event)
{
	switch (event) {
        case FL_PUSH:
			switch(shapeMode) {
                case MyWindow::LINE:
				    if(clickCounter == 0) {
					    startX = Fl::event_x() - swidth/2;    //Get the X mouse position
					    startY = sheight/2 - Fl::event_y();   //Get the Y mouse position
                    }
				    else if(clickCounter == 1) {
					    finishX = Fl::event_x() - swidth/2;   //Get end point of line X coord 
					    finishY = sheight/2 - Fl::event_y(); //Get end point of line Y coord
					}
				    clickCounter = (clickCounter + 1) % 2;
			        redraw();
			        return 1;
                    
		   	    case MyWindow::CIRCLE:
				    //Get center point of circle
                    //Calculate circle radius
                    return 1;
                    
			    case MyWindow::POLYLINE:
                    //handle multiple points here
                    return 1;
            }
    }
	return Fl_Gl_Window::handle(event);

}

//-----------------------------------------------------------------------------

// ************************************************************************
// Clean the window and clear all the variables
// ************************************************************************

void MyWindow::clearallvariables()
{
    shapeMode = MyWindow::CLEAR;
    clickCounter = 0;
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    redraw();
}


