/*
 *	MyWindow.h
 *
 *	Created on : Jan 26, 2013
 *  Updated on : Feb 01, 2013
 *  Course     : CS4610/7610
 *  Instructor : Kannappan Palaniappan
 *	Author	   : Rui Wang
 *	Purpose    : Class definition for main drawing&viewing window 
 *
 *	Copyright University of Missouri-Columbia
 */

#ifndef MY_WINDOW_H
#define MY_WINDOW_H


#include <FL/Fl_Gl_Window.h>
#include <string>
#include <iostream>
#include <fstream>

class MyWindow : public Fl_Gl_Window
{
   public:
      MyWindow(int x,int y,int width, int height, char* title);
      virtual ~MyWindow();
      void InitializeGL();
      virtual void draw();
	  
	/*<<<<<<<<<<<<<<<<<<<<<drawMouseLine>>>>>>>>>>>>>>>>>>>>>
	 Enables interactive line drawing
	 */
	void drawline();
	
	/*<<<<<<<<<<<<<<<<<<<<<drawMouseCircle>>>>>>>>>>>>>>>>>>>
	 Enables interactive circle drawing
	 */
	void drawcircle();
	
	/*<<<<<<<<<<<<<<<<<<<<<drawMousePolyline>>>>>>>>>>>>>>>>>
	 Enables interactive polyline drawing
     */
	void drawpolyline();
    
    /*<<<<<<<<<<<<<<<<<<<<<drawMouseDialogPoint>>>>>>>>>>>>>>
	 Enables interactive dialogpoint drawing
     */
	void drawdialogpoint();
    
    /*<<<<<<<<<<<<<<<<<<<<ClearShapeVariables>>>>>>>>>>>>>>>>
     */
	void clearallvariables();
	
	// handles the keyboard and mouse input
	  virtual int handle(int event);
    
	 
	//Set of static variables to represent the shapes 
	static const int CLEAR;
	static const int LINE;
	static const int CIRCLE;
	static const int ELLIPSE;
	static const int POLYLINE;
	static const int POLYGON;
	static const int RASTERIZE;
	static const int FILLCIRCLE;
	static const int SEMICIRCLE;
	static const int RUBBERLINE;
	static const int RUBBERCIRCLE;
	static const int RUBBERPOLYLINE;
    static const int DIALOGPOINT;
	
	//screen size
	int swidth;
	int sheight;
	
	//mouse click counter
	int clickCounter;
	
	//line start and end point
	int startX, startY ,finishX, finishY;
    
    //dialog points
    int dialogX,dialogY;
	
	//Initialization
	int firsttime;
	
private:
	//The current shape being drawn (line, circle or ellipse)
	int shapeMode;
};

#endif
