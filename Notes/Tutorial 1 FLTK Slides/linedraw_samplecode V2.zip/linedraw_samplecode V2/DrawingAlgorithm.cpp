/*
 *	DrwaingAlgorithm.cpp
 *
 *	Created on : Jan 26, 2013
 *  Course     : CS4610/7610
 *  Instructor : Kannappan Palaniappan
 *	Author	   : Rui Wang
 *	Purpose    : Implement all drawing algoritms (eg. Bresenham line and circle) 
 *
 *	Copyright University of Missouri-Columbia
 */


#include "DrawingAlgorithm.h"
#include <FL/gl.h>
#include <stdlib.h>



void DrawingAlgorithms::Bresenham(int xs, int ys, int xe, int ye)
{
    //Replace it with Bresenham drawing algorithm.
	glBegin(GL_LINES);
    glVertex2i(xs, ys);
    glVertex2i(xe, ye);
    glEnd();
   
}

