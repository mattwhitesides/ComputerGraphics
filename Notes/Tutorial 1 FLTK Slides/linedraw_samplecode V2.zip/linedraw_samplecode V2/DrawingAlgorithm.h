/*
 *	DrawingAlgorithm.h
 *
 *	Created on : Jan 26, 2013
 *  Course     : CS4610/7610
 *  Instructor : Kannappan Palaniappan
 *	Author	   : Rui Wang
 *	Purpose    : Define all drawing functions.
 *
 *	Copyright University of Missouri-Columbia
 */


#ifndef DRAWINGALGORITHMS_H
#define DRAWINGALGORITHMS_H


class DrawingAlgorithms
{
public:
    /*<<<<<<<<<<<<<<<<<<<<<drawline>>>>>>>>>>>>>>>>>>>>>>>>
	 Insert your comments here
	 */
	static void Bresenham(int xs, int ys, int xe, int ye);
	
};
#endif